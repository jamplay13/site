# 🌍 NewsStream — Site de Notícias em Tempo Real

Este pacote contém tudo pronto para você rodar, personalizar e publicar seu site de notícias.

## 📂 O que está incluso
- Código completo (Next.js + API + SSE + fallback Pusher)
- Dockerfile para deploy em Cloud Run
- vercel.json para deploy em Vercel
- Logo em cartoon (public/logo.png)
- Script init_repo.sh (para criar e subir repositório GitHub)
- pusher-implementation.txt com instruções extras
- README com guia completo de deploy

## 🚀 Passos Rápidos
1. Renomeie `.env.example` para `.env` e adicione sua `NEWSAPI_KEY` e, opcionalmente, credenciais do Pusher.
2. Rode localmente:
   ```bash
   npm install
   npm run dev
   ```
3. Suba para GitHub:
   ```bash
   chmod +x init_repo.sh
   ./init_repo.sh
   ```
4. Deploy no Vercel ou Cloud Run (veja abaixo).

## ☁️ Deploy no Vercel
- Crie conta em [vercel.com](https://vercel.com)
- Importe o repositório GitHub
- Configure variáveis de ambiente (NEWSAPI_KEY, PUSHER_…)
- Clique em Deploy

## ☁️ Deploy no Google Cloud Run
- Autentique no gcloud: `gcloud auth login`
- `gcloud builds submit --tag gcr.io/SEU_PROJECT_ID/newsstream`
- `gcloud run deploy newsstream --image gcr.io/SEU_PROJECT_ID/newsstream --platform managed --region us-central1 --allow-unauthenticated`
- Configure variáveis no console

## 🌐 Domínio via Cloudflare
- Adicione domínio no painel do Cloudflare
- Crie CNAME apontando para Vercel ou Cloud Run
- SSL automático habilitado

## 🔔 Testando Pusher
Se configurado, envie evento de teste:
```bash
curl -X POST https://SEU_DOMINIO/api/pusher_trigger   -H "Content-Type: application/json"   -d '{"title":"🚨 Teste","description":"Notícia simulada"}'
```

## ✅ Checklist Produção
- [ ] Trocar logo (public/logo.png) se quiser personalizar
- [ ] Confirmar variáveis de ambiente
- [ ] Adicionar páginas de política de privacidade e contato
- [ ] Monitoramento (Sentry ou outro)
