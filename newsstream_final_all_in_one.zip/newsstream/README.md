# NewsStream — Site de notícias (Brasil & Mundo)

This package includes:
- Next.js frontend
- API routes for top headlines and SSE
- Dockerfile for containerized deploy (Cloud Run / ECS)
- vercel.json for Vercel deployment tuning
- Optional Pusher integration (use PUSHER_* env vars)

## Quick local run
1. copy .env.example to .env and add NEWSAPI_KEY
2. npm install
3. npm run dev

## Deploy to Vercel
1. Push to GitHub and import project in Vercel
2. Add env vars: NEWSAPI_KEY, (optional) PUSHER_APP_ID,PUSHER_KEY,PUSHER_SECRET,PUSHER_CLUSTER
3. Deploy

## Deploy with Docker (Cloud Run)
1. Build and push to container registry
2. Deploy to Cloud Run or ECS

## Pusher notes
- To use Pusher in production, install the `pusher` npm package and replace the placeholder code
- Add PUSHER_APP_ID, PUSHER_KEY, PUSHER_SECRET, PUSHER_CLUSTER to environment

## Visual customization
- Color variables are in styles/globals.css (--accent, --bg, --text)
- Replace public/logo.png with your logo
