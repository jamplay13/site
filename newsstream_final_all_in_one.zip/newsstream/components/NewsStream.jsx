import { useEffect } from 'react';

export default function NewsStream({ onNews }) {
  useEffect(() => {
    const PUSHER_KEY = process.env.NEXT_PUBLIC_PUSHER_KEY || null;
    const PUSHER_CLUSTER = process.env.NEXT_PUBLIC_PUSHER_CLUSTER || null;

    let pusherClient = null;
    let channel = null;

    async function setupPusher() {
      try {
        // dynamic import so dev environment without pusher-js doesn't break
        const Pusher = (await import('pusher-js')).default;
        pusherClient = new Pusher(PUSHER_KEY, { cluster: PUSHER_CLUSTER });
        channel = pusherClient.subscribe('news');
        channel.bind('breaking', (data) => {
          onNews && onNews(data);
        });
        console.log('Pusher client connected');
      } catch (e) {
        console.warn('Pusher client failed, falling back to SSE', e);
        setupSSE();
      }
    }

    function setupSSE() {
      const es = new EventSource('/api/events');
      es.addEventListener('news', e => {
        try {
          const data = JSON.parse(e.data);
          onNews && onNews(data);
        } catch (err) { console.error(err); }
      });
      es.onerror = (err) => {
        console.error('SSE error', err);
        es.close();
      };
      return es;
    }

    let sse = null;
    if (PUSHER_KEY) {
      setupPusher();
    } else {
      sse = setupSSE();
    }

    return () => {
      if (pusherClient && channel) {
        channel.unbind_all && channel.unbind_all();
        pusherClient.unsubscribe && pusherClient.unsubscribe('news');
        pusherClient.disconnect && pusherClient.disconnect();
      }
      if (sse) sse.close();
    };
  }, [onNews]);

  return null;
}
