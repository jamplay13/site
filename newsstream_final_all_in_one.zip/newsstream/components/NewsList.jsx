export function NewsCard({ article }) {
  return (
    <article style={{border:'1px solid #ddd', padding:12, borderRadius:8, marginBottom:12}}>
      <h3 style={{margin:0}}>{article.title}</h3>
      <p style={{margin:'8px 0'}}>{article.summary}</p>
      <div style={{fontSize:12, color:'#666'}}>
        <span>{article.source}</span> • <span>{new Date(article.publishedAt).toLocaleString()}</span>
      </div>
      <a href={article.url} target="_blank" rel="noreferrer">ver original</a>
    </article>
  );
}

export default function NewsList({ articles = [] }) {
  return (
    <div>
      {articles.map(a => <NewsCard key={a.id} article={a} />)}
    </div>
  );
}
