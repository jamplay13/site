import { useEffect, useState } from 'react';
import NewsList from '../components/NewsList';
import NewsStream from '../components/NewsStream';

export default function Home({ initial }) {
  const [articles, setArticles] = useState(initial || []);

  useEffect(() => {
    const id = setInterval(async () => {
      const r = await fetch('/api/top?country=br');
      const j = await r.json();
      if (j && j.articles) setArticles(j.articles);
    }, 60000);
    return () => clearInterval(id);
  }, []);

  function handleNews(n) {
    setArticles(prev => [n, ...prev.filter(x => x.id !== n.id)].slice(0, 50));
  }

  return (
    <main style={{maxWidth:900, margin:'0 auto', padding:20}}>
      <h1>NewsStream — Brasil & Mundo (tempo real)</h1>
      <p>Últimas notícias — conectado por SSE</p>
      <NewsStream onNews={handleNews} />
      <NewsList articles={articles} />
    </main>
  );
}

export async function getServerSideProps() {
  const host = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  const res = await fetch(`${host}/api/top?country=br`);
  const json = await res.json();
  return { props: { initial: json.articles || [] } };
}
