// pages/api/events.js — SSE with Pusher fallback (production-ready)
import { fetchTop } from '../../lib/newsApi';
import Pusher from 'pusher';

const USE_PUSHER = !!process.env.PUSHER_APP_ID;
let clients = [];

function sendEvent(res, data) {
  try {
    res.write(`event: news\ndata: ${JSON.stringify(data)}\n\n`);
  } catch (e) { console.error('sendEvent err', e); }
}

export default async function handler(req, res) {
  if (USE_PUSHER) {
    // If Pusher configured, inform client to use Pusher (SSE not needed).
    res.status(200).json({ ok: true, pusher: true });
    return;
  }

  if (req.method !== 'GET') {
    res.status(405).end();
    return;
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders && res.flushHeaders();

  const id = Date.now() + Math.random();
  const client = { id, res };
  clients.push(client);

  sendEvent(res, { message: 'connected' });

  req.on('close', () => {
    clients = clients.filter(c => c.id !== id);
  });
}

// broadcaster
let intervalStarted = false;
async function startBroadcast() {
  if (intervalStarted) return;
  intervalStarted = true;
  const poll = Number(process.env.NEWS_POLL_INTERVAL_SECONDS || 60) * 1000;
  const pusher = USE_PUSHER ? new Pusher({
    appId: process.env.PUSHER_APP_ID,
    key: process.env.PUSHER_KEY,
    secret: process.env.PUSHER_SECRET,
    cluster: process.env.PUSHER_CLUSTER,
    useTLS: true
  }) : null;

  setInterval(async () => {
    try {
      const latest = await fetchTop({ country: 'us' });
      const item = latest && latest[0];
      if (!item) return;

      if (USE_PUSHER && pusher) {
        // server-side pusher trigger using pusher REST API via library
        // Note: pusher.trigger returns a Promise in the official lib only on server-side HTTP calls.
        try {
          await pusher.trigger('news', 'breaking', item);
          console.log('Pushed via Pusher:', item.title);
        } catch (err) {
          console.error('pusher trigger error', err);
        }
      } else {
        clients.forEach(c => sendEvent(c.res, item));
      }
    } catch (e) {
      console.error('broadcast err', e);
    }
  }, poll);
}
startBroadcast();
