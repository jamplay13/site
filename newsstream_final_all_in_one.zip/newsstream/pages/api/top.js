// rota /api/top?country=br
import { fetchTop } from '../../lib/newsApi';

export default async function handler(req, res) {
  try {
    const { country = 'br', category } = req.query;
    const articles = await fetchTop({ country, category });
    res.setHeader('Cache-Control', 's-maxage=30, stale-while-revalidate=60');
    res.status(200).json({ ok: true, articles });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, error: 'failed' });
  }
}
