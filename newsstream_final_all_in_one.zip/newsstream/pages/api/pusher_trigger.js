// pages/api/pusher_trigger.js
// Endpoint to manually trigger a push (for testing / webhooks)
import Pusher from 'pusher';

const pusher = new Pusher({
  appId: process.env.PUSHER_APP_ID,
  key: process.env.PUSHER_KEY,
  secret: process.env.PUSHER_SECRET,
  cluster: process.env.PUSHER_CLUSTER,
  useTLS: true
});

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ ok:false, message: 'POST only' });
    return;
  }
  const payload = req.body || {};
  try {
    await pusher.trigger('news', 'breaking', payload);
    res.status(200).json({ ok:true });
  } catch (err) {
    console.error('pusher trigger err', err);
    res.status(500).json({ ok:false, error: String(err) });
  }
}
