#!/bin/bash
# init_repo.sh - initialize git repo and push to GitHub (fill your username and repo name)
set -e
if [ -z "$1" ]; then
  echo "Usage: ./init_repo.sh GITHUB_USER/REPO_NAME"
  exit 1
fi
REPO=$1
git init
git add .
git commit -m "Initial scaffold: NewsStream with Pusher & Docker"
git branch -M main
git remote add origin https://github.com/${REPO}.git
echo "Pushing to https://github.com/${REPO}.git (you will be asked for credentials)..."
git push -u origin main
