# Cassino Sandbox 🎰 (Demo) — Full Stack

**Este é um projeto de demonstração (sandbox) de um site de cassino.**  
⚠️ **Não utiliza dinheiro real.**

---

## 🚀 Deploy rápido

### Backend (Render)
1. Crie conta em [Render](https://render.com).
2. Clique em **New → Web Service** e conecte este repositório.
3. Configure:
   - Build Command: `cd backend && npm install`
   - Start Command: `cd backend && npm start`
   - Variáveis de ambiente:
     - `DATABASE_URL` → URL do Postgres (Render oferece “New Database”).
     - `JWT_SECRET` → segredo seguro (ex: `minhaChaveUltraSecreta`).
4. Crie também um banco Postgres no Render e copie a string para `DATABASE_URL`.

### Frontend (Netlify)
1. Crie conta em [Netlify](https://netlify.com).
2. Clique em **Add new site → Import from GitHub**.
3. Configure:
   - Build Command: `cd frontend && npm install && npm run build`
   - Publish Directory: `frontend/dist`
   - Variáveis de ambiente:
     - `VITE_API_URL` → URL pública do backend no Render (ex: `https://cassino-backend.onrender.com`).

---

## 🛠️ Desenvolvimento local

Pré-requisitos:
- Node.js 18+
- Docker (para Postgres)

Rodar localmente:
```bash
# iniciar banco
docker-compose up -d db

# backend
cd backend
npm install
npm run dev

# frontend
cd frontend
npm install
npm run dev
```

---

## 📂 Estrutura
```
cassino-sandbox/
 ├─ backend/        # API Node/Express
 ├─ frontend/       # React + Vite
 ├─ docker-compose.yml
 ├─ LICENSE
 ├─ README.md
 └─ .github/workflows/ci.yml
```

---

## ✅ CI/CD (GitHub Actions)
O repositório já vem com GitHub Actions (`.github/workflows/ci.yml`) que:
- Roda `npm install` e `npm run build` no frontend.
- Roda `npm install` e inicia o backend (verifica se compila).

---

## ⚖️ Aviso legal
Este projeto é **apenas para estudo e demonstração**.  
Para operar jogos de azar com dinheiro real é necessário obter **licença** e cumprir requisitos legais rigorosos (KYC/AML, RNG auditado, PCI-DSS, etc).
