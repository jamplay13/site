#!/bin/bash
echo "Start Postgres via docker-compose (if you have docker)"
docker-compose up -d db
echo "Then in separate shells: "
echo "cd backend && npm install && npm run dev"
echo "cd frontend && npm install && npm run dev"
