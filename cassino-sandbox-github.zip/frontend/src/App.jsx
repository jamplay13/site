import React, {useState, useEffect} from 'react';
import axios from 'axios';

const API = (import.meta.env.VITE_API_URL) || 'http://localhost:4000';

function Login({onLogin}) {
  const [email,setEmail] = useState('');
  const [pass,setPass] = useState('');
  async function doLogin() {
    const r = await axios.post(`${API}/api/login`, { email, password: pass }).catch(e=>null);
    if(r?.data?.token) onLogin(r.data.token);
    else alert('erro');
  }
  return (<div style={{padding:12}}>
    <h3>Login / Register (demo)</h3>
    <input placeholder='email' value={email} onChange={e=>setEmail(e.target.value)} /><br/>
    <input placeholder='senha' value={pass} onChange={e=>setPass(e.target.value)} /><br/>
    <button onClick={doLogin}>Login</button>
  </div>);
}

function GamePanel({token, onRefresh}) {
  const [balance, setBalance] = useState(0);
  useEffect(()=>{ if(!token) return; axios.get('/api-proxy/me', { headers: { Authorization: 'Bearer '+token } }).then(r=>setBalance(r.data.balance)).catch(()=>{}); }, [token]);
  async function bet(game){
    const stake = parseInt(prompt('Aposta (número)', '10'),10);
    if(!stake) return;
    const r = await axios.post('/api-proxy/bet', { game, stake }, { headers: { Authorization: 'Bearer '+token } });
    alert('Resultado: payout=' + (r.data.payout ?? 0));
    onRefresh?.();
  }
  async function deposit(){
    const amount = parseInt(prompt('Valor para depositar (simulado)', '100'),10);
    if(!amount) return;
    await axios.post('/api-proxy/sandbox/deposit', { amount }, { headers: { Authorization: 'Bearer '+token } });
    alert('Deposit feito (simulado)');
    onRefresh?.();
  }
  return (<div style={{padding:12}}>
    <h3>Painel</h3>
    <div>Saldo: <strong>{balance}</strong></div>
    <button onClick={()=>bet('coin')}>Apostar Moeda (50/50)</button>
    <button onClick={()=>bet('slot')}>Apostar Slot</button>
    <button onClick={deposit}>Depositar (sandbox)</button>
  </div>);
}

export default function App(){
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [profile, setProfile] = useState(null);

  useEffect(()=> {
    // simple proxy for browser CORS in dev: we will assume user runs backend on 4000 and configure vite proxy locally.
    // but to make quick tests without proxy, we create dev endpoints in vite config (instructions in README).
  }, []);

  const onLogin = (t) => { localStorage.setItem('token', t); setToken(t); };
  const logout = ()=>{ localStorage.removeItem('token'); setToken(null); setProfile(null); };

  return (<div style={{fontFamily:'system-ui',maxWidth:900,margin:'20px auto',color:'#062'}}>
    <h1>Cassino Sandbox — Demo</h1>
    {!token ? <Login onLogin={onLogin} /> : <div>
      <button onClick={logout}>Sair</button>
      <GamePanel token={token} onRefresh={()=>{ /* trigger refresh by reloading */ window.location.reload(); }} />
    </div>}
    <p style={{marginTop:20}}>Este é um ambiente de teste — sem dinheiro real.</p>
  </div>);
}
